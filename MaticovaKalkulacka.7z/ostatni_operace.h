#pragma once 

float determinant(int c, int r, float m[c][r]);
void transpozice(int c, int r, float m[c][r]);