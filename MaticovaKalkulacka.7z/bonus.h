#pragma once

int rank(int c, int r, float m[c][r]);
void inverse(int n, float m[n][n]);