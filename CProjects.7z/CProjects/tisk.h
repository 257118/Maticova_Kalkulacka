#pragma once

void printf_fprintf_function(int c, int r, float matice[c][r]);