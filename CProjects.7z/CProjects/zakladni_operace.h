#pragma once

void scitani(int c, int r, float m1[c][r], float m2[c][r]);
void odcitani(int c, int r, float m1[c][r], float m2[c][r]);
void nasobeni(int c1, int r1, int c2, int r2, float m1[c1][r1], float m2[c2][r2]);
void skalar(int c, int r, float s, float m[c][r]);